from abc import ABC, abstractmethod
from typing import Optional, Tuple

import numpy as np

from domain.models import CalibrationData, Pose3D


class PoseEstimator(ABC):
    @abstractmethod
    def estimate_pose(
        self, corners: np.ndarray, marker_length_m: float, calib: CalibrationData, center: Optional[bool] = False
    ) -> Tuple[Pose3D, np.ndarray, np.ndarray]:
        """
        Estimate pose from detected corners.
        :param corners: detected corners (numpy array)
        :param marker_length_m: length of marker detected (in meters)
        :param calib: calibration data (CalibrationData object)
        :param center: center of pose estimation
        :return: Tuple[Pose3D, rotation_vectors, translation_vectors]
            - Estimated pose as Pose3D object
            - Rotation vectors
            - Translation vectors
        """
