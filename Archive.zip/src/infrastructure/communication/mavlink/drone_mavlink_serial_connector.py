from pymavlink import mavutil

from .drone_mavlink_base import DroneMavlinkBase
from .mavlink_connection_params import MavlinkConnectionParams


class DroneMavlinkSerialConnector(DroneMavlinkBase):
    def __init__(self, params: MavlinkConnectionParams):
        super().__init__(params)

    def _init_mavlink_connection(self) -> None:
        self.connection = mavutil.mavlink_connection(
            self.parameters.address, baud=self.parameters.baud_rate, source_component=191
        )
